# S.U.T.R.A. Node Demo

Simulated hazard-fusion logic for the SUTRA node: Green / Yellow / Red status from waste type, water level, flow, and cover readings.

## Run

```
python sutra_demo.py
```

Requires Python 3.7 or newer. No external packages.

## What it shows

- **Red:** open cover, critical water level, or a likely blockage (high level with plastic or organic waste).
- **Yellow:** silent node (heartbeat timeout), or high level or flow.
- **Green:** normal.

Node SUT-003 loses its link from tick 5 to 9, so it turns Yellow once the heartbeat timeout passes.

## Notes

- Sensor readings are simulated. Replace `read_sensors()` with real drivers on the node MCU.
- Thresholds are placeholders. Update them after Stage 3 tuning and pilot feedback.
