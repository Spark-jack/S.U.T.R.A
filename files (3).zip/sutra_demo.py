"""
S.U.T.R.A. node demo: hazard fusion and Green / Yellow / Red status.
Simulated sensors only. Replace read_sensors() with real drivers on the node MCU.
"""
import random
from dataclasses import dataclass

GREEN, YELLOW, RED = "GREEN", "YELLOW", "RED"

HEARTBEAT_TIMEOUT = 3      # ticks without a heartbeat before status goes Yellow
LEVEL_WARN_CM = 60         # water depth that signals a possible blockage
LEVEL_CRIT_CM = 85         # water depth that signals imminent flooding
FLOW_SURGE_LPM = 40        # flow rate treated as a surge


@dataclass
class Reading:
    node_id: str
    location: str
    waste: str             # "plastic", "organic", or "stone" (NIR class)
    level_cm: float
    flow_lpm: float
    cover_open: bool


def read_sensors(node_id, location, tick):
    """Simulated readings. Replace with real sensor drivers on the node."""
    return Reading(
        node_id=node_id,
        location=location,
        waste=random.choice(["plastic", "organic", "stone"]),
        level_cm=random.uniform(10, 95),
        flow_lpm=random.uniform(0, 60),
        cover_open=random.random() < 0.03,
    )


def fuse(r: Reading, ticks_since_heartbeat: int):
    """Combine all sensors into one status and a reason, following slide 12."""
    if r.cover_open:
        return RED, "cover open or displaced"
    if r.level_cm >= LEVEL_CRIT_CM:
        return RED, "water level critical"
    if r.level_cm >= LEVEL_WARN_CM and r.waste in ("plastic", "organic"):
        return RED, f"likely blockage ({r.waste} waste, level rising)"
    if ticks_since_heartbeat > HEARTBEAT_TIMEOUT:
        return YELLOW, "node silent (heartbeat timeout)"
    if r.level_cm >= LEVEL_WARN_CM or r.flow_lpm >= FLOW_SURGE_LPM:
        return YELLOW, "level or flow above normal"
    return GREEN, "normal"


def send_alert(r: Reading, status: str, reason: str, tick: int):
    """Stands in for the app, SMS, and e-mail alerts on slide 9."""
    print(f"[tick {tick:02d}] ALERT {status:<6} | {r.node_id} @ {r.location} | {reason}")


def run(ticks=10):
    nodes = {
        "SUT-001": "Hostel block drain",
        "SUT-002": "Library parking inlet",
        "SUT-003": "Main gate storm drain",
    }
    last_heartbeat = {n: 0 for n in nodes}

    for tick in range(1, ticks + 1):
        for node_id, location in nodes.items():
            # Simulate a lost LoRa link for SUT-003 from tick 5 to 9
            if node_id == "SUT-003" and 5 <= tick <= 9:
                ticks_silent = tick - last_heartbeat[node_id]
                status, reason = fuse(
                    Reading(node_id, location, "stone", 0, 0, False),
                    ticks_silent,
                )
                if status != GREEN:
                    send_alert(Reading(node_id, location, "", 0, 0, False), status, reason, tick)
                continue

            r = read_sensors(node_id, location, tick)
            last_heartbeat[node_id] = tick
            status, reason = fuse(r, 0)
            if status != GREEN:
                send_alert(r, status, reason, tick)


if __name__ == "__main__":
    random.seed(7)   # repeatable demo run
    run()
